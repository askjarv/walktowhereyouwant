// Configuration for the Fitbit API
window.config = {
    CLIENT_ID: 'YOUR_CLIENT_ID',
    REDIRECT_URI: 'https://askjarv.github.io/walktowhereyouwant/'
}; 